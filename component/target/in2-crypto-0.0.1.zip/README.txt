Instructions for usage

This guide contains instructions to install the Crypto ballerina package into your ballerina installation. This is a one-time task.
Once done, you can then use this package across all your ballerina projects.

In this directory, you can find two scripts of interest to you. Please note that when running the following scripts,
you will need write permission to the Ballerina installation location.

1. install.{sh/bat} - Installs the Redis package.
2. uninstall.{sh/bat} - Uninstalls the Redis package if installed already.

Happy coding!
